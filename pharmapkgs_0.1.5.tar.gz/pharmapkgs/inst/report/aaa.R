#' This file is present only to make sure that
#' inst/report folder is preserved in the package tarball.
#' @noRd
NULL
