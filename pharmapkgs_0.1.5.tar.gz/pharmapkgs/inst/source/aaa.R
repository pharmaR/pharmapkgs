#' This file is present only to make sure that
#' inst/source folder is preserved in the package tarball.
#' @noRd
NULL
