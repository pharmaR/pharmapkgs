.onLoad <- function(lib, pkg) {
  .setup_logger()
  .init_config_values()
}
