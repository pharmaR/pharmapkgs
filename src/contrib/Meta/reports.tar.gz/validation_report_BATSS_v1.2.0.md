# This report is fully automated and builds on [rhub/ref-image](https://hub.docker.com/r/rhub/ref-image) image.

2026-05-29 12:00:00

# Context

Documents the installation of this package on an open source R
environment, focusing on:

- Installation environment description
- Testing coverage

It is limited to assess whether unit tests and documentation are present
and can execute without error. An assessment would be required that the
tests and documentation are meaningful.

# Package BATSS

## Metric based risk assessment

The following metrics are derived from the `riskmetric` R package.

| Downloads.1.year | Reverse.dependencies | License | Origin |
|:-----------------|---------------------:|:--------|:-------|
| 2757             |                    0 | GPL-2   | NA     |

| Section | Values |
|:---|:---|
| Has news | No |
| Exported namespace | 12 |
| Has vignettes | Yes |
| Export help | 12 |
| Has website | Yes |
| Has maintainer | Dominique-Laurent Couturier <dominique.couturier@mrc-bsu.cam.ac.uk> |
| Bugs status | package DESCRIPTION does not have a BugReports field |
| Size codebase | 1327 |
| Has bug reports url | No |
| Has examples | 100.00% |
| Dependencies | 10 |

**Package general assessment:** Coverage, check results, size, download
the last year, reverse dependencies and number of dependencies.

# Installation environment

## System Info

| Field          | Value                   |
|:---------------|:------------------------|
| Image          | rhub/ref-image          |
| OS             | Ubuntu 24.04.4 LTS      |
| Platform       | x86_64-pc-linux-gnu     |
| System         | x86_64, linux-gnu       |
| Execution Time | 2026-05-29 06:47:57 UTC |

**System information**. Table about the system used to check the
package.

<!--
From here we use the lua filter based on this issue from Quarto itself
https://github.com/quarto-dev/quarto-cli/issues/341
Please take into account that not all content in the chunks will be correctly folded
- character vectors are
- reactable tables are not
An alternative is to use callout blocks with collapse = TRUE
The advantage of the foldable_code lua filter is that the code is printed exactly as in the R console
-->

## R Session Info

<details><summary>Session info</summary>

``` details
R version 4.6.0 (2026-04-24)
Platform: x86_64-pc-linux-gnu
Running under: Ubuntu 24.04.4 LTS

Matrix products: default
BLAS:   /usr/lib/x86_64-linux-gnu/openblas-pthread/libblas.so.3 
LAPACK: /usr/lib/x86_64-linux-gnu/openblas-pthread/libopenblasp-r0.3.26.so;  LAPACK version 3.12.0

locale:
 [1] LC_CTYPE=C.UTF-8       LC_NUMERIC=C           LC_TIME=C.UTF-8       
 [4] LC_COLLATE=C.UTF-8     LC_MONETARY=C.UTF-8    LC_MESSAGES=C.UTF-8   
 [7] LC_PAPER=C.UTF-8       LC_NAME=C              LC_ADDRESS=C          
[10] LC_TELEPHONE=C         LC_MEASUREMENT=C.UTF-8 LC_IDENTIFICATION=C   

time zone: UTC
tzcode source: system (glibc)

attached base packages:
[1] tools     stats     graphics  grDevices utils     datasets  methods  
[8] base     

other attached packages:
[1] riskreports_0.0.0.9006 knitr_1.51            

loaded via a namespace (and not attached):
 [1] jsonlite_2.0.0      compiler_4.6.0      BiocManager_1.30.27
 [4] Rcpp_1.1.1-1.1      xml2_1.5.2          covr_3.6.5         
 [7] urltools_1.7.3.1    riskmetric_0.2.7    triebeard_0.4.1    
[10] yaml_2.3.12         fastmap_1.2.0       R6_2.6.1           
[13] curl_7.1.0          htmlwidgets_1.6.4   backports_1.5.1    
[16] tibble_3.3.1        cranlogs_2.1.1      reactable_0.4.5    
[19] pillar_1.11.1       rlang_1.2.0         cachem_1.1.0       
[22] reactR_0.6.1        xfun_0.57           fs_2.1.0           
[25] pkgload_1.5.2       otel_0.2.0          rex_1.2.2          
[28] memoise_2.0.1       cli_3.6.6           magrittr_2.0.5     
[31] digest_0.6.39       devtools_2.5.2      lifecycle_1.0.5    
[34] vctrs_0.7.3         evaluate_1.0.5      glue_1.8.1         
[37] sessioninfo_1.2.3   pkgbuild_1.4.8      rmarkdown_2.31     
[40] purrr_1.2.2         httr_1.4.8          usethis_3.2.1      
[43] pkgconfig_2.0.3     ellipsis_0.3.3      htmltools_0.5.9    
```

</details>

<details><summary>Platform</summary>

``` details
   OS.type   file.sep dynlib.ext        GUI     endian    pkgType   path.sep 
    "unix"        "/"      ".so"      "X11"   "little"   "source"        ":" 
    r_arch 
        "" 
```

</details>

<details><summary>R's capabilities</summary>

``` details
       jpeg         png        tiff       tcltk         X11        aqua 
       TRUE        TRUE        TRUE        TRUE       FALSE       FALSE 
   http/ftp     sockets      libxml        fifo      cledit       iconv 
       TRUE        TRUE       FALSE        TRUE       FALSE        TRUE 
        NLS       Rprof     profmem       cairo         ICU long.double 
       TRUE        TRUE        TRUE        TRUE        TRUE        TRUE 
    libcurl 
       TRUE 
```

</details>

<details><summary>External software</summary>

``` details
                                                     zlib 
                                                    "1.3" 
                                                    bzlib 
                                     "1.0.8, 13-Jul-2019" 
                                                       xz 
                                                  "5.4.5" 
                                               libdeflate 
                                                   "1.19" 
                                                     zstd 
                                                  "1.5.5" 
                                                     PCRE 
                                       "10.42 2022-12-11" 
                                                      ICU 
                                                   "74.2" 
                                                      TRE 
                                "TRE 0.8.0 R_fixes (BSD)" 
                                                    iconv 
                                             "glibc 2.39" 
                                                 readline 
                                                    "8.2" 
                                                     BLAS 
"/usr/lib/x86_64-linux-gnu/openblas-pthread/libblas.so.3" 
```

</details>

<details><summary>Graphics external software</summary>

``` details
                   cairo                  cairoFT                    pango 
                "1.18.0"                       ""                 "1.52.1" 
                  libpng                     jpeg                  libtiff 
                "1.6.43"                    "8.0" "LIBTIFF, Version 4.5.1" 
```

</details>

<details><summary>Numerical characteristics of the machine</summary>

``` details
               double.eps            double.neg.eps               double.xmin 
             2.220446e-16              1.110223e-16             2.225074e-308 
              double.xmax               double.base             double.digits 
            1.797693e+308              2.000000e+00              5.300000e+01 
          double.rounding              double.guard         double.ulp.digits 
             5.000000e+00              0.000000e+00             -5.200000e+01 
    double.neg.ulp.digits           double.exponent            double.min.exp 
            -5.300000e+01              1.100000e+01             -1.022000e+03 
           double.max.exp               integer.max               sizeof.long 
             1.024000e+03              2.147484e+09              8.000000e+00 
          sizeof.longlong         sizeof.longdouble            sizeof.pointer 
             8.000000e+00              1.600000e+01              8.000000e+00 
            sizeof.time_t            longdouble.eps        longdouble.neg.eps 
             8.000000e+00              1.084202e-19              5.421011e-20 
        longdouble.digits       longdouble.rounding          longdouble.guard 
             6.400000e+01              5.000000e+00              0.000000e+00 
    longdouble.ulp.digits longdouble.neg.ulp.digits       longdouble.exponent 
            -6.300000e+01             -6.400000e+01              1.500000e+01 
       longdouble.min.exp        longdouble.max.exp 
            -1.638200e+04              1.638400e+04 
```

</details>

<details><summary>Random number generation process</summary>

``` details
[1] "Mersenne-Twister" "Inversion"        "Rejection"       
```

</details>

## Information about the environment

Environmental and options variables affect how package checks and
software in it might behave.

<details><summary>Environmental variables when running this report</summary>

``` details
_R_CHECK_SYSTEM_CLOCK_
                        FALSE
ACCEPT_EULA             Y
ACTIONS_ORCHESTRATION_ID
                        77c084bf-a033-4d8e-aa45-d647cd011619.main.ubuntu-22_04_4_4
ACTIONS_RUNNER_ACTION_ARCHIVE_CACHE
                        /opt/actionarchivecache
ACTIONS_RUNNER_RETURN_JOB_RESULT_FOR_HOSTED
                        1
AGENT_TOOLSDIRECTORY    /opt/hostedtoolcache
ANDROID_HOME            /usr/local/lib/android/sdk
ANDROID_NDK             /usr/local/lib/android/sdk/ndk/27.3.13750724
ANDROID_NDK_HOME        /usr/local/lib/android/sdk/ndk/27.3.13750724
ANDROID_NDK_LATEST_HOME
                        /usr/local/lib/android/sdk/ndk/29.0.14206865
ANDROID_NDK_ROOT        /usr/local/lib/android/sdk/ndk/27.3.13750724
ANDROID_SDK_ROOT        /usr/local/lib/android/sdk
ANT_HOME                /usr/share/ant
AZURE_EXTENSION_DIR     /opt/az/azcliextensions
BOOTSTRAP_HASKELL_NONINTERACTIVE
                        1
BUNDLE_EXT              linux-amd64.deb
CHROME_BIN              /usr/bin/google-chrome
CHROMEWEBDRIVER         /usr/local/share/chromedriver-linux64
CI                      true
CONDA                   /usr/share/miniconda
DEBIAN_FRONTEND         noninteractive
DENO_DOM_PLUGIN         /opt/quarto/bin/tools/x86_64/deno_dom/libplugin.so
DENO_NO_UPDATE_CHECK    1
DENO_TLS_CA_STORE       system,mozilla
DOTNET_MULTILEVEL_LOOKUP
                        0
DOTNET_NOLOGO           1
DOTNET_SKIP_FIRST_TIME_EXPERIENCE
                        1
EDGEWEBDRIVER           /usr/local/share/edge_driver
EDITOR                  vi
ENABLE_RUNNER_TRACING   true
GECKOWEBDRIVER          /usr/local/share/gecko_driver
GHCUP_INSTALL_BASE_PREFIX
                        /usr/local
GITHUB_ACTION           __run_4
GITHUB_ACTION_REF       
GITHUB_ACTION_REPOSITORY
                        
GITHUB_ACTIONS          true
GITHUB_ACTOR            llrs-roche
GITHUB_ACTOR_ID         185338939
GITHUB_API_URL          https://api.github.com
GITHUB_BASE_REF         
GITHUB_ENV              /home/runner/work/_temp/_runner_file_commands/set_env_f6e3412d-9554-47a0-a704-18011320e691
GITHUB_EVENT_NAME       schedule
GITHUB_EVENT_PATH       /home/runner/work/_temp/_github_workflow/event.json
GITHUB_GRAPHQL_URL      https://api.github.com/graphql
GITHUB_HEAD_REF         
GITHUB_JOB              main
GITHUB_OUTPUT           /home/runner/work/_temp/_runner_file_commands/set_output_f6e3412d-9554-47a0-a704-18011320e691
GITHUB_PATH             /home/runner/work/_temp/_runner_file_commands/add_path_f6e3412d-9554-47a0-a704-18011320e691
GITHUB_REF              refs/heads/main
GITHUB_REF_NAME         main
GITHUB_REF_PROTECTED    false
GITHUB_REF_TYPE         branch
GITHUB_REPOSITORY       pharmaR/pharmapkgs
GITHUB_REPOSITORY_ID    798326913
GITHUB_REPOSITORY_OWNER
                        pharmaR
GITHUB_REPOSITORY_OWNER_ID
                        42115094
GITHUB_RETENTION_DAYS   90
GITHUB_RUN_ATTEMPT      1
GITHUB_RUN_ID           26622499936
GITHUB_RUN_NUMBER       605
GITHUB_SERVER_URL       https://github.com
GITHUB_SHA              fc8ac43e34c1fd1cbb69d2a585314f0e7fffb52f
GITHUB_STATE            /home/runner/work/_temp/_runner_file_commands/save_state_f6e3412d-9554-47a0-a704-18011320e691
GITHUB_STEP_SUMMARY     /home/runner/work/_temp/_runner_file_commands/step_summary_f6e3412d-9554-47a0-a704-18011320e691
GITHUB_TRIGGERING_ACTOR
                        llrs-roche
GITHUB_WORKFLOW         Update package repositories
GITHUB_WORKFLOW_REF     pharmaR/pharmapkgs/.github/workflows/update-repos.yml@refs/heads/main
GITHUB_WORKFLOW_SHA     fc8ac43e34c1fd1cbb69d2a585314f0e7fffb52f
GITHUB_WORKSPACE        /home/runner/work/pharmapkgs/pharmapkgs
GOROOT_1_22_X64         /opt/hostedtoolcache/go/1.22.12/x64
GOROOT_1_23_X64         /opt/hostedtoolcache/go/1.23.12/x64
GOROOT_1_24_X64         /opt/hostedtoolcache/go/1.24.13/x64
GOROOT_1_25_X64         /opt/hostedtoolcache/go/1.25.10/x64
GRADLE_HOME             /usr/share/gradle-9.5.1
HOME                    /home/runner
HOMEBREW_CLEANUP_PERIODIC_FULL_DAYS
                        3650
HOMEBREW_NO_AUTO_UPDATE
                        1
ImageOS                 ubuntu24
ImageVersion            20260525.161.1
INVOCATION_ID           70d9466010b7467eb6101dbb46b82deb
JAVA_HOME               /usr/lib/jvm/temurin-17-jdk-amd64
JAVA_HOME_11_X64        /usr/lib/jvm/temurin-11-jdk-amd64
JAVA_HOME_17_X64        /usr/lib/jvm/temurin-17-jdk-amd64
JAVA_HOME_21_X64        /usr/lib/jvm/temurin-21-jdk-amd64
JAVA_HOME_25_X64        /usr/lib/jvm/temurin-25-jdk-amd64
JAVA_HOME_8_X64         /usr/lib/jvm/temurin-8-jdk-amd64
JOURNAL_STREAM          9:14710
LANG                    C.UTF-8
LD_LIBRARY_PATH         /opt/R/4.6.0/lib/R/lib:/usr/local/lib:/usr/lib/x86_64-linux-gnu:/usr/lib/jvm/temurin-17-jdk-amd64/lib/server:/opt/R/4.6.0/lib/R/lib:/usr/local/lib:/usr/lib/x86_64-linux-gnu:/usr/lib/jvm/temurin-17-jdk-amd64/lib/server
LN_S                    ln -s
LOGGER_LOG_LEVEL        DEBUG
LOGNAME                 runner
MAKE                    make
MEMORY_PRESSURE_WATCH   /sys/fs/cgroup/system.slice/hosted-compute-agent.service/memory.pressure
MEMORY_PRESSURE_WRITE   c29tZSAyMDAwMDAgMjAwMDAwMAA=
NOT_CRAN                true
NVM_DIR                 /home/runner/.nvm
PAGER                   /usr/bin/pager
PATH                    /snap/bin:/home/runner/.local/bin:/opt/pipx_bin:/home/runner/.cargo/bin:/home/runner/.config/composer/vendor/bin:/usr/local/.ghcup/bin:/home/runner/.dotnet/tools:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
PHARMAPKGS_EXCLUDED_METRICS
                        assess_covr_coverage,assess_r_cmd_check
PHARMAPKGS_LIMIT        100
PHARMAPKGS_LOCAL_REPO   /home/runner/work/pharmapkgs/pharmapkgs
PHARMAPKGS_PLATFORM     ubuntu-22.04
PHARMAPKGS_R_VERSION    4.4
PHARMAPKGS_REMOTE_REPO
                        https://cloud.r-project.org/
PIPX_BIN_DIR            /opt/pipx_bin
PIPX_HOME               /opt/pipx
PKGCACHE_HTTP_VERSION   2
PKGLOAD_PARENT_TEMPDIR
                        /tmp/RtmpEQYkXI
POWERSHELL_DISTRIBUTION_CHANNEL
                        GitHub-Actions-Linux
PROCESSX_PS1a1c63b4e400_1780037257
                        YES
PSModulePath            /root/.local/share/powershell/Modules:/usr/local/share/powershell/Modules:/opt/microsoft/powershell/7/Modules:/usr/share/az_14.6.0
PWD                     /home/runner/work/pharmapkgs/pharmapkgs
QUARTO_BIN_PATH         /opt/quarto/bin
QUARTO_DENO             /opt/quarto/bin/tools/x86_64/deno
QUARTO_DOCUMENT_FILE    validation_report_BATSS_v1.2.0.qmd
QUARTO_DOCUMENT_PATH    /home/runner/work/pharmapkgs/pharmapkgs/src/contrib/Meta
QUARTO_EXECUTE_INFO     /home/runner/work/pharmapkgs/pharmapkgs/.quarto/quarto-session-tempc04c2817aee1fa9/67fb1a2d844f5835
QUARTO_PROFILE          
QUARTO_PROJECT_DIR      /home/runner/work/pharmapkgs/pharmapkgs
QUARTO_PROJECT_ROOT     /home/runner/work/pharmapkgs/pharmapkgs
QUARTO_ROOT             /
QUARTO_SHARE_PATH       /opt/quarto/share
R_ARCH                  
R_BROWSER               xdg-open
R_BZIPCMD               /usr/bin/bzip2
R_DOC_DIR               /opt/R/4.6.0/lib/R/doc
R_GZIPCMD               /usr/bin/gzip
R_HOME                  /opt/R/4.6.0/lib/R
R_INCLUDE_DIR           /opt/R/4.6.0/lib/R/include
R_LIB_FOR_PAK           /opt/R/4.6.0/lib/R/site-library
R_LIBS_SITE             /opt/R/4.6.0/lib/R/site-library
R_LIBS_USER             /home/runner/work/_temp/Library
R_PAPERSIZE             letter
R_PAPERSIZE_USER        letter
R_PDFVIEWER             /usr/bin/xdg-open
R_PLATFORM              x86_64-pc-linux-gnu
R_PRINTCMD              /usr/bin/lpr
R_RD4PDF                times,inconsolata,hyper
R_SESSION_TMPDIR        /tmp/RtmpKeTRLK
R_SHARE_DIR             /opt/R/4.6.0/lib/R/share
R_STRIP_SHARED_LIB      strip --strip-unneeded
R_STRIP_STATIC_LIB      strip --strip-debug
R_TEXI2DVICMD           /usr/bin/texi2dvi
R_UNZIPCMD              /usr/bin/unzip
R_ZIPCMD                /usr/bin/zip
RENV_CONFIG_REPOS_OVERRIDE
                        https://packagemanager.posit.co/cran/__linux__/noble/latest
RSPM                    https://packagemanager.posit.co/cran/__linux__/noble/latest
RUNNER_ARCH             X64
RUNNER_ENVIRONMENT      github-hosted
RUNNER_NAME             GitHub Actions 1000005926
RUNNER_OS               Linux
RUNNER_TEMP             /home/runner/work/_temp
RUNNER_TOOL_CACHE       /opt/hostedtoolcache
RUNNER_TRACKING_ID      github_d7117d9e-794e-46fd-a4b7-f48f2254202e
RUNNER_WORKSPACE        /home/runner/work/pharmapkgs
SED                     /usr/bin/sed
SELENIUM_JAR_PATH       /usr/share/java/selenium-server.jar
SGX_AESM_ADDR           1
SHELL                   /bin/bash
SHLVL                   1
SWIFT_PATH              /usr/share/swift/usr/bin
SYSTEMD_EXEC_PID        2012
TAR                     /usr/bin/tar
TZ                      UTC
USE_BAZEL_FALLBACK_VERSION
                        silent:
USER                    runner
VCPKG_INSTALLATION_ROOT
                        /usr/local/share/vcpkg
XDG_CONFIG_HOME         /home/runner/.config
XDG_RUNTIME_DIR         /run/user/1001
```

</details>

<details><summary>These are the options set to generate the report</summary>

``` details
$add.smooth
[1] TRUE

$bitmapType
[1] "cairo"

$browser
[1] "xdg-open"

$browserNLdisabled
[1] FALSE

$callr.condition_handler_cli_message
function (msg) 
{
    custom_handler <- getOption("cli.default_handler")
    if (is.function(custom_handler)) {
        custom_handler(msg)
    }
    else {
        cli_server_default(msg)
    }
}
<bytecode: 0x5602a7f38080>
<environment: namespace:cli>

$catch.script.errors
[1] FALSE

$CBoundsCheck
[1] FALSE

$check.bounds
[1] FALSE

$citation.bibtex.max
[1] 1

$continue
[1] "+ "

$contrasts
        unordered           ordered 
"contr.treatment"      "contr.poly" 

$covr.covrignore
[1] ".covrignore"

$covr.exclude_end
#[[:space:]]*nocov[[:space:]]*end

$covr.exclude_pattern
#[[:space:]]*nocov

$covr.exclude_start
#[[:space:]]*nocov[[:space:]]*start

$covr.flags
          CFLAGS         CXXFLAGS       CXX1XFLAGS       CXX11FLAGS 
"-O0 --coverage" "-O0 --coverage" "-O0 --coverage" "-O0 --coverage" 
      CXX14FLAGS       CXX17FLAGS       CXX20FLAGS           FFLAGS 
"-O0 --coverage" "-O0 --coverage" "-O0 --coverage" "-O0 --coverage" 
         FCFLAGS            FLIBS          LDFLAGS 
"-O0 --coverage"         "-lgcov"     "--coverage" 

$covr.gcov
           gcov 
"/usr/bin/gcov" 

$covr.icov
codecov 
     "" 

$covr.icov_flags
                CFLAGS               CXXFLAGS             CXX1XFLAGS 
"-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" 
            CXX11FLAGS             CXX14FLAGS             CXX17FLAGS 
"-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" 
            CXX20FLAGS                 FFLAGS                FCFLAGS 
"-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" 
               LDFLAGS           SHLIB_LIBADD 
"-O0 -prof-gen=srcpos" "-O0 -prof-gen=srcpos" 

$covr.icov_prof
profmerge 
       "" 

$covr.record_tests
[1] TRUE

$defaultPackages
[1] "datasets"  "utils"     "grDevices" "graphics"  "stats"     "methods"  

$demo.ask
[1] "default"

$deparse.cutoff
[1] 60

$device
function (width = 7, height = 7, ...) 
{
    grDevices::pdf(NULL, width, height, ...)
}
<bytecode: 0x5602a8d71188>
<environment: namespace:knitr>

$device.ask.default
[1] FALSE

$devtools.ellipsis_action
function (message = NULL, class = NULL, ..., body = NULL, footer = NULL, 
    parent = NULL, use_cli_format = NULL, .inherit = NULL, .frequency = c("always", 
        "regularly", "once"), .frequency_id = NULL, .subclass = deprecated()) 
{
    message <- validate_signal_args(message, class, NULL, .subclass, 
        "warn")
    message_info <- cnd_message_info(message, body, footer, caller_env(), 
        use_cli_format = use_cli_format)
    message <- message_info$message
    extra_fields <- message_info$extra_fields
    use_cli_format <- message_info$use_cli_format
    .frequency <- arg_match0(.frequency, c("always", "regularly", 
        "once"))
    if (!needs_signal(.frequency, .frequency_id, warning_freq_env, 
        "rlib_warning_verbosity")) {
        return(invisible(NULL))
    }
    if (!is_null(parent)) {
        if (is_null(.inherit)) {
            .inherit <- !inherits(parent, "error")
        }
        extra_fields$rlang <- c(extra_fields$rlang, list(inherit = .inherit))
    }
    cnd <- warning_cnd(class, message = message, !!!extra_fields, 
        use_cli_format = use_cli_format, parent = parent, ...)
    cnd$footer <- c(cnd$footer, message_freq(message, .frequency, 
        "warning"))
    local_long_messages()
    warning(cnd)
}
<bytecode: 0x5602a93774f8>
<environment: namespace:rlang>

$devtools.install.args
[1] ""

$devtools.path
[1] "~/R-dev"

$digits
[1] 7

$dvipscmd
[1] "dvips"

$echo
[1] FALSE

$editor
[1] "vi"

$encoding
[1] "native.enc"

$example.ask
[1] "default"

$expressions
[1] 5000

$help.search.types
[1] "vignette" "demo"     "help"    

$help.try.all.packages
[1] FALSE

$htmltools.preserve.raw
[1] TRUE

$HTTPUserAgent
[1] "R/4.6.0 R (4.6.0 x86_64-pc-linux-gnu x86_64 linux-gnu) on GitHub Actions"

$httr_oauth_cache
[1] NA

$httr_oob_default
[1] FALSE

$internet.info
[1] 2

$keep.parse.data
[1] TRUE

$keep.parse.data.pkgs
[1] FALSE

$keep.source
[1] FALSE

$keep.source.pkgs
[1] FALSE

$knitr.in.progress
[1] TRUE

$locatorBell
[1] TRUE

$mailer
[1] "mailto"

$matprod
[1] "default"

$max.contour.segments
[1] 25000

$max.print
[1] 99999

$menu.graphics
[1] TRUE

$na.action
[1] "na.omit"

$Ncpus
[1] 1

$nwarnings
[1] 50

$OutDec
[1] "."

$pager
[1] "/opt/R/4.6.0/lib/R/bin/pager"

$papersize
[1] "letter"

$PCRE_limit_recursion
[1] NA

$PCRE_study
[1] FALSE

$PCRE_use_JIT
[1] TRUE

$pdfviewer
[1] "/usr/bin/xdg-open"

$pkgType
[1] "source"

$printcmd
[1] "/usr/bin/lpr"

$prompt
[1] "> "

$quiet
[1] TRUE

$repos
                                                         RSPM 
"https://packagemanager.posit.co/cran/__linux__/noble/latest" 
                                                         CRAN 
                                   "https://cran.rstudio.com" 

$riskmetric.github_api_host
[1] "https://api.github.com"

$riskmetric.gitlab_api_host
[1] "https://gitlab.com/api/v4"

$riskmetric.per_package_request
[1] FALSE

$rl_word_breaks
[1] " \t\n\"\\'`><=;,|&{()}"

$rlang_trace_top_env
<environment: R_GlobalEnv>

$scipen
[1] 0

$show.coef.Pvalues
[1] TRUE

$show.error.messages
[1] TRUE

$show.signif.stars
[1] TRUE

$showErrorCalls
[1] TRUE

$showNCalls
[1] 50

$showWarnCalls
[1] FALSE

$str
$str$strict.width
[1] "no"

$str$digits.d
[1] 3

$str$vec.len
[1] 4

$str$list.len
[1] 99

$str$deparse.lines
NULL

$str$drop.deparse.attr
[1] TRUE

$str$formatNum
function (x, ...) 
format(x, trim = TRUE, drop0trailing = TRUE, ...)
<environment: 0x5602a7a150f8>


$str.dendrogram.last
[1] "`"

$texi2dvi
[1] "/usr/bin/texi2dvi"

$tikzMetricsDictionary
[1] "validation_report_BATSS_v1.2.0-tikzDictionary"

$timeout
[1] 60

$try.outFile
A connection with                    
description ""      
class       "file"  
mode        "w+b"   
text        "binary"
opened      "opened"
can read    "yes"   
can write   "yes"   

$ts.eps
[1] 1e-05

$ts.S.compat
[1] FALSE

$unzip
[1] "/usr/bin/unzip"

$useFancyQuotes
[1] FALSE

$verbose
[1] FALSE

$warn
[1] 0

$warning.length
[1] 1000

$warnPartialMatchArgs
[1] FALSE

$warnPartialMatchAttr
[1] FALSE

$warnPartialMatchDollar
[1] FALSE

$width
[1] 80
```

</details>
